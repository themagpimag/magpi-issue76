# Extend Python’s capabilities
from gpiozero import LED
from time import sleep

# Set ‘red’ to represent the LED
red = LED(17)

# Loop forever
while True:

    # Send current to the LED for one second
    red.on()
    sleep(1)
    
    # Stop the current for one second
    red.off()
    sleep(1)