# Extend Python’s capabilities
from gpiozero import LED, Button
from signal import pause

# Assign these variables to our LED and button
led = LED(17)
button = Button(18)

# Assign events that are triggered when the button is used
button.when_pressed = led.on
button.when_released = led.off

# This command prevents Python from exiting
pause()