def getPlayerImage():
    global player
    # we need to import datetime at the top of our code
    dt = datetime.now()
    a = player.angle
    # this next line will give us a number between
    # 0 and 5 depending on the time and SPEED
    tc = dt.microsecond%(500000/SPEED)/(100000/SPEED)
    if tc > 2.5 and (player.movex != 0 or player.movey !=0):
        # this is for the closed mouth images
        if a != 180:
            player.image = "pacman_c"
        else:
            # reverse image if facing left
            player.image = "pacman_cr"
    else:
        # this is for the open mouth images
        if a != 180:
            player.image = "pacman_o"
        else:
            player.image = "pacman_or"
    # set the angle on the player actor
    player.angle = a
    
