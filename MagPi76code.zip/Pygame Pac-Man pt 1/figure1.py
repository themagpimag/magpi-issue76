# gameinput Module

from pygame import joystick, key
from pygame.locals import *

joystick.init()
joystick_count = joystick.get_count()

if(joystick_count > 0):
    joyin = joystick.Joystick(0)
    joyin.init()
    # For the purposes of this tutorial
    # we are only going to use the first
    # joystick that is connected.
    
